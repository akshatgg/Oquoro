
import { PrismaClient } from '@prisma/client';
import { NextResponse } from 'next/server';
import { getUserIdFromToken } from '@/utils/getUser';

const prisma = new PrismaClient();

// POST: Add an answer to a question
export async function POST(req, { params }) {
  const { id: questionId } = params;
  const { answerBody, userAnswered } = await req.json();
  const userId = await getUserIdFromToken(req);

  try {
    const question = await prisma.question.findUnique({ where: { id: questionId } });
    if (!question) {
      return NextResponse.json({ message: 'Question not found' }, { status: 404 });
    }

    const newAnswer = await prisma.answer.create({
      data: {
        answerBody,
        userAnswered,
        userId,
        questionId,
      },
    });

    // Update the number of answers
    const answersCount = await prisma.answer.count({ where: { questionId } });
    await prisma.question.update({
      where: { id: questionId },
      data: { noOfAnswers: answersCount },
    });

    return NextResponse.json({ message: 'Answer posted successfully', answer: newAnswer }, { status: 201 });
  } catch (error) {
    console.error('Answer Posting Error:', error);
    return NextResponse.json({ message: 'Something went wrong' }, { status: 500 });
  }
}